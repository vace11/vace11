---
name: Feature request
about: Suggest an idea for xmr-stak.

---

**Please explain the feature as good as possible.**

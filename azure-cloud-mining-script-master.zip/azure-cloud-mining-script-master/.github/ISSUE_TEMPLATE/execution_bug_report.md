---
name: Execution bug report
about: You have an issue to execute xmr-stak.

---

**Most execution issues are caused by driver problems. Please use the [xmr-stak sub-reddit](https://www.reddit.com/r/XmrStak/) to ask for help instead of opening an issue here.**
